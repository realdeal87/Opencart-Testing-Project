"""Модуль загружает общую функциональность из пакета common"""
from .Alert import Alert
