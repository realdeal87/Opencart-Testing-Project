"""Локаторы для меню главной страницы сайта Opencart"""


class Menu:
    """Локаторы для меню"""

    components = {'link': 'Components'}

    monitors = {'part_link': 'Monitors'}
