"""Локаторы для раздела Downloads панели администратора сайта Opencart"""


class Downloads:
    """Локаторы для раздела Downloads"""
    download_name = {'class': 'form-control'}
