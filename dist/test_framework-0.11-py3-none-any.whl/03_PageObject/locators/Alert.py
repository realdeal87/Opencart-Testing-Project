"""Локаторы для алертингов на сайте Opencart"""


class Alert:
    """Локаторы алертингов"""
    alert_success = {'class': 'alert-success'}
    alert_danger = {'class': 'alert-danger'}
