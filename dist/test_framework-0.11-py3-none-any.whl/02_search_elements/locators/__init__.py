"""Модуль загружает локаторы из пакета locators"""
from .Alerts import Alerts
from .DashBoard import DashBoard
from .DirPart import DirPart
from .LoginPanel import LoginPanel
from .MainPage import MainPage
from .ProductCard import ProductCard
